from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from functools import partial

# 1.创建连接数据库的引擎，session连接数据库
# engine = create_engine("mysql+pymysql://root:root@172.16.81.129:3306/nms_db",
#     max_overflow=0,
#     pool_size=5,
#     pool_timeout=30,
#     pool_recycle=120
# )
engine = create_engine("mysql+pymysql://root:root@172.16.81.129:3306/nms_db", poolclass=None)
# 2.创建一个配置过的DBSession类
DBSession = sessionmaker(bind=engine)
# 3.实例化一个session
session = DBSession()
# 4.使用session
'''
    flush：   预提交，提交到数据库文件，还未写入数据库文件中
    commit：  提交了一个事务
    rollback：回滚
    close：   关闭
'''
@contextmanager
def session_scope(maker):
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()

nms_session_scope = partial(session_scope, maker=session)