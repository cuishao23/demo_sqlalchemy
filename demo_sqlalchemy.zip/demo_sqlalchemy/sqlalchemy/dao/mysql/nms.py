"""数据库映射"""
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Table, Column, Integer, String, Enum, SmallInteger, Enum, Date, ForeignKey, DateTime, Text
import enum

Base = declarative_base()


class LevelEnum(enum.Enum):
    critical = '1'
    important = '2'
    normal = '3'

# 创建数据库表类（模型）
class ServerWarningUnrepaired(Base):
    __tablename__ = 'server_warning_unrepaired'
    
    id = Column(Integer, primary_key=True)
    device_moid = Column(String(40))
    device_name = Column(String(128), nullable=True)
    device_type = Column(String(36), nullable=True)
    device_ip = Column(String(128), nullable=True)
    machine_room_moid = Column(String(40))
    machine_room_name = Column(String(128), nullable=True)
    code = Column(Integer)
    level = Column(Enum(LevelEnum))
    description = Column(String(128), nullable=True)
    start_time = Column(DateTime)
    resolve_time = Column(DateTime, nullable=True)