from dao.mysql.nms import *
from dao.mysql import nms_session_scope
from sqlalchemy import and_, or_, func, text

def init():
    with nms_session_scope() as session:
        # 1.增
        data = {
            'device_moid': '00c94e09-b7ba-4ce7-9132-c5f5b72415b1',
            'device_name': 'xmpu5',
            'device_type': 'nds',
            'device_ip': '172.16.81.129',
            'machine_room_moid': 'mooooooo-oooo-oooo-oooo-defaultmachi',
            'machine_room_name': '默认机房',
            'code': '2020',
            'level': 'important',
            'description': '测试',
            'start_time': '2020-08-24 15:17:39.000000'
        }
        info = ServerWarningUnrepaired(
            device_moid=data.get('device_moid'),
            device_name=data.get('device_name'),
            device_type=data.get('device_type'),
            device_ip=data.get('device_ip'),
            machine_room_moid=data.get('machine_room_moid'),
            machine_room_name=data.get('machine_room_name'),
            code=data.get('code'),
            level=data.get('level'),
            description=data.get('description'),
            start_time=data.get('start_time'),
            resolve_time=data.get('resolve_time')
        )
        session.add(info)
        
        datas = [{
            'device_moid': '00c94e09-b7ba-4ce7-9132-c5f5b72415b1',
            'device_name': 'xmpu5',
            'device_type': 'nds',
            'device_ip': '172.16.81.129',
            'machine_room_moid': 'mooooooo-oooo-oooo-oooo-defaultmachi',
            'machine_room_name': '默认机房',
            'code': '2020',
            'level': 'important',
            'description': '测试',
            'start_time': '2020-08-24 15:17:39.000000'
           },
           {
            'device_moid': '00c94e09-b7ba-4ce7-9132-c5f5b72415b1',
            'device_name': 'xmpu5',
            'device_type': 'nds',
            'device_ip': '172.16.81.129',
            'machine_room_moid': 'mooooooo-oooo-oooo-oooo-defaultmachi',
            'machine_room_name': '默认机房',
            'code': '2020',
            'level': 'important',
            'description': '添加',
            'start_time': '2020-08-24 15:17:39.000000'
          }
        ]
        infos = []
        for data in datas:
            info = ServerWarningUnrepaired(
                device_moid=data.get('device_moid'),
                device_name=data.get('device_name'),
                device_type=data.get('device_type'),
                device_ip=data.get('device_ip'),
                machine_room_moid=data.get('machine_room_moid'),
                machine_room_name=data.get('machine_room_name'),
                code=data.get('code'),
                level=data.get('level'),
                description=data.get('description'),
                start_time=data.get('start_time'),
                resolve_time=data.get('resolve_time')
            )
            infos.append(info)
        session.add_all(infos) 


        # 2.删
        session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.id == 30).delete(synchronize_session='fetch')


        # 3.改
        session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.id == 21).first().description = '修改'


        # 4.查
        result = session.query(ServerWarningUnrepaired).all()
        for i in result:
            print(i.device_name)

        result = session.query(ServerWarningUnrepaired).all()[0:3]
        for i in result:
            print(i.id)
      
        result = session.query(ServerWarningUnrepaired.device_name, ServerWarningUnrepaired.id).all()
        a = {}
        for i in result:
            a[i[0]] = set()
            # print(a)
            a[i[0]].add(i[1])
        print(a)
        
        result = session.query(ServerWarningUnrepaired).first()
        print(result.device_name)

        resault = session.query(ServerWarningUnrepaired).order_by(ServerWarningUnrepaired.id)
        for i in resault:
            print(i.id)
        
        resault = session.query(ServerWarningUnrepaired).order_by(-ServerWarningUnrepaired.id)
        for i in resault:
            print(i.id)

        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.id == 21)
        for i in result:
            print(i.device_name)
        
        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.device_name != 'modb_10.23.46.39')
        for i in result:
            print(i.device_name)
        
        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.id.in_([1,2,3]))
        for i in result:
            print(i.id)

        result = session.query(ServerWarningUnrepaired).filter(~ServerWarningUnrepaired.id.in_([1,2,3]))
        for i in result:
            print(i.id)

        result = session.query(ServerWarningUnrepaired).filter(and_(ServerWarningUnrepaired.level == 'critical', ServerWarningUnrepaired.device_type == 'umm'))
        for i in result:
            print(i.device_type)

        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.level == 'critical', ServerWarningUnrepaired.device_type == 'umm')
        for i in result:
            print(i.device_type)

        result = session.query(ServerWarningUnrepaired).filter(or_(ServerWarningUnrepaired.device_type == 'sus', ServerWarningUnrepaired.device_type == 'umm'))
        for i in result:
            print(i.device_type)

        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.device_name.like('%s%'))
        for i in result:
            print(i.device_name)

        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.device_name.like('S%'))
        for i in result:
            print(i.device_name)

        result = session.query(ServerWarningUnrepaired).filter(ServerWarningUnrepaired.device_name.like('%2'))
        for i in result:
            print(i.device_name)

        result = session.query(ServerWarningUnrepaired).count()
        print(result)

        result = session.query(func.count('*')).select_from(ServerWarningUnrepaired).scalar()
        print(result)

        result = session.query(func.count(ServerWarningUnrepaired.device_name), ServerWarningUnrepaired.device_name).group_by(ServerWarningUnrepaired.device_name).all()
        print(result)

        result = session.query(ServerWarningUnrepaired).from_statement(text('select * from server_warning_unrepaired where device_name=:device_name')).params(device_name='10.23.46.39').all()
        print(result)
        for i in result:
            print(i.device_name)



if __name__ == "__main__":
    init()
